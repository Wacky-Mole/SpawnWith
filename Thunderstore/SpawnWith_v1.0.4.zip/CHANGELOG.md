| `Version` | `Update Notes`    |
|-----------|-------------------|
| 1.0.4     | - Updated SS  + 217.46 Update |
| 1.0.3     | - Updated ServerSync |
| 1.0.2     | - Added SteamWorld Verification- Only spawn one set of Items no matter how many Chars created for the world.  |
| 1.0.1     | - Cleanup |
| 1.0.0     | - Initial Release |