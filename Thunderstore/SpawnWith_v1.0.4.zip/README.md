# SpawnWith
### By WackyMole

Spawns Starting Items

1) Install Bepinex

2) Use Config File and Drop it in the Config Folder or Run Valheim once to generate one.

3) Config Config File. "Prefab:amount,Item2Prefab:Item2Amount" 
  -- Don't use extra spaces, use extra commas to seperate items.

4) This has ServerSync on it, just load it up on Server and enjoy

5) It only works ONE time for a single SteamID in a single world. Can work for existing Characters with WorldSteamCheck = true 
<br>Otherwise only works for new characters that have not spawned in any world. 


6) Multiplayer Servers should really use https://valheim.thunderstore.io/package/Smoothbrain/ServerCharacters/  instead for anti cheating. 
